﻿using Microsoft.AspNet.Hosting;
using Microsoft.AspNetCore.Builder;
using Microsoft.DotNet.InternalAbstractions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.PlatformAbstractions;
using Prototyp1.Services;

namespace Prototyp1
{
    public class Startup
    {
        public static IConfigurationRoot Configuration;
        public Startup () // IHostingEnvironment env)
        {
            //var builder = new ConfigurationBuilder()
            //.SetBasePath(env.WebRootPath)
            //.AddJsonFile("config.json");
            //Configuration = builder.Build();
        }
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit http://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            // kommentar
            services.AddMvc();
            services.AddScoped<IMailService, DebugMailService>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app)
        {
            app.UseStaticFiles();
            app.UseMvc(config =>
            {
                config.MapRoute(
                    name: "Default",
                    template: "{controller}/{action}/{id?}",
                    defaults: new { Controller = "App", action = "Index" }
                    );
            });


            //app.Run(async (context) =>
            //{
            //    await context.Response.WriteAsync("Hello World!");
            //});
        }
    }
}


