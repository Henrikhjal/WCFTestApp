﻿(function () {
    var body = $("body");
    body.on("mouseenter", function () {
        // alert("Hej");
    })
})();