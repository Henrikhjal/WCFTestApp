﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Prototyp1.Models
{
    public class Message
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "Namn")]
        [Required]

        public string Name { get; set; }

        [Display(Name = "Meddelande")]
        [Required]

        public string MessageText { get; set; }

        public DateTime Date { get; set; }
    }
}
