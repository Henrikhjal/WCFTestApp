﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Prototyp1.Models
{
    public enum SexType
    {
        [Display(Name = "Man")]
        Man = 1,

        [Display(Name = "Kvinna")]
        Woman = 2,
    }

    public class User
    {
        [Required]
        [Display(Name = "Användare-Id")]
        [StringLength(20, MinimumLength = 4)]
        public string Id { get; set; }

        [StringLength(20, MinimumLength = 4)]
        public string FirstName { get; set; }
        [StringLength(30, MinimumLength = 4)]
        public string SurName { get; set; }
        public bool SexType { get; set; }

        [EmailAddress]
        public string Email { get; set; }

        [Range(1, 200)]
        public int Weight { get; set; }

        [Range(50, 250)]
        public int Length { get; set; }
    }
}
