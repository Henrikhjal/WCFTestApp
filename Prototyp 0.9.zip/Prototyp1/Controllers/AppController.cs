﻿using Microsoft.AspNetCore.Mvc;
using Prototyp1.Models;

namespace Prototyp1.Controllers
{
    public class AppController : Controller
    {
        //private IMailService _mailService;

        //public AppController(IMailService service)
        //{
        //    _mailService = service;
        //}

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Activities()
        {
            return View();
        }

        public IActionResult Health()
        {
            return View();
        }

        public IActionResult Contacts()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Contact(Message message)
        {
            return View();
        }

        public IActionResult Profile()
        {
            return View();
        }

        [HttpPost]

        public IActionResult Profile(User user)
        {
            return View();
        }
    }

}
