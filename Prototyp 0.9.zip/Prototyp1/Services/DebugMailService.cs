﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Prototyp1.Services
{
    public class DebugMailService : IMailService
    {
        public bool SendMail(string from, string to, string subject, string body)
        {
            Debug.WriteLine(from);
            Debug.WriteLine(to);
            Debug.WriteLine(body);
            return true;
        }
    }
}
